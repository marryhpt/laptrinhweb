#!/bin/bash
docker-compose -f ./service/docker-compose.yml up -d --build
