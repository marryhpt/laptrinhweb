<?php
session_start();
require_once ('process/dbh.php');
if (!isset($_SESSION['id'])) {
    header('location:logout.php');
}else{
    //check quyen
    $id=$_SESSION['id'];
    $sql = "SELECT * from `alogin` WHERE id=$id";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) == 0){
        header("Location: logout.php");
    }
}


$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="utf-8">
    <title>Quản lý | Hệ thống quản lý nhân viên</title>
    <!-- Thêm liên kết tới Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .active-nav {
            background-color: #ffc107 !important;
            color: white !important;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #28a745;">
            <a class="navbar-brand text-white" href="#">HVT Company</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'aloginwel.php') ? 'active-nav' : ''; ?>" href="aloginwel.php">Trang chủ</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'addemp.php') ? 'active-nav' : ''; ?>" href="addemp.php">Thêm nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'viewemp.php') ? 'active-nav' : ''; ?>" href="viewemp.php">Danh sách nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'assign.php') ? 'active-nav' : ''; ?>" href="assign.php">Giao dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'assignproject.php') ? 'active-nav' : ''; ?>" href="assignproject.php">Trạng thái dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'salaryemp.php') ? 'active-nav' : ''; ?>" href="salaryemp.php">Bảng lương</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'empleave.php') ? 'active-nav' : ''; ?>" href="empleave.php">Đơn xin nghỉ</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="logout.php">ĐĂNG XUẤT</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <div class="container mt-5">
        <h2 class="text-center">Thông tin đăng ký</h2>
        <div class="card mt-3">
            <div class="card-body">
                <form action="process/addempprocess.php" method="POST" enctype="multipart/form-data">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <input class="form-control" type="text" placeholder="Họ" name="lastName" required>
                        </div>
                        <div class="form-group col-md-6">
                            <input class="form-control" type="text" placeholder="Tên" name="firstName" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="email" placeholder="Email" name="email" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Ngày sinh</label>
                            <input class="form-control" type="date" name="birthday" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Giới tính</label>
                            <select name="gender" class="form-control" required>
                                <option value="" disabled selected>Chọn giới tính</option>
                                <option value="Male">Nam</option>
                                <option value="Female">Nữ</option>
                                <option value="Other">Khác</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" placeholder="Số điện thoại" name="contact" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" placeholder="Địa chỉ" name="address" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" placeholder="Phòng ban" name="dept" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" placeholder="Bằng cấp" name="degree" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="number" placeholder="Lương" name="salary">
                    </div>
                    <div class="form-group">
                        <label>Chọn file ảnh</label>
                        <input class="form-control-file" type="file" name="file">
                    </div>
                    <button type="submit" class="btn btn-success">Gửi</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Thêm liên kết tới jQuery và Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
