<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<header>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #007bff; border-radius: 10px;"> <!-- Đổi màu navbar thành xanh dương -->
        <a class="navbar-brand text-white" href="#">LTALVA Company</a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo ($current_page == 'eloginwel.php') ? 'active-nav' : ''; ?>" href="eloginwel.php">Trang chủ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo ($current_page == 'myprofile.php') ? 'active-nav' : ''; ?>" href="myprofile.php">Hồ sơ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo ($current_page == 'empproject.php') ? 'active-nav' : ''; ?>" href="empproject.php">Dự án</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo ($current_page == 'applyleave.php') ? 'active-nav' : ''; ?>" href="applyleave.php">Xin nghỉ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="logout.php">ĐĂNG XUẤT</a>
                </li>
            </ul>
        </div>
    </nav>
</header>

<style>
    .active-nav {
        background-color: #ff007f !important; /* Màu hồng cho mục active */
        color: white !important;
        border-radius: 5px; /* Bo góc cho mục active */
    }
</style>
