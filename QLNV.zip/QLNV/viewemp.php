<?php
session_start();
require_once('process/dbh.php');

// Kiểm tra đăng nhập
if (!isset($_SESSION['id'])) {
    header('location:logout.php');
    exit();
}

// Kiểm tra quyền truy cập
$id = $_SESSION['id'];
$sql = "SELECT * FROM `alogin` WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if (mysqli_num_rows($result) == 0) {
    header("Location: logout.php");
    exit();
}

// Lấy danh sách nhân viên và thông tin cấp bậc
$sql = "SELECT * FROM `employee`, `rank` WHERE employee.id = rank.eid";
$result = mysqli_query($conn, $sql);

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý | Hệ thống quản lý nhân viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f7fa;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #0044cc;
            color: white;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar h1 {
            font-size: 2rem;
            margin: 0;
            color: white;
            font-weight: bold;
        }

        .sidebar {
            background-color: #003366;
            color: #ffffff;
            height: 100vh;
            position: fixed;
            top: 60px;
            left: 0;
            width: 250px;
            overflow-y: auto;
            padding: 30px 0;
            border-right: 1px solid #ddd;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: #ffffff;
            text-decoration: none;
            font-size: 1rem;
            border-radius: 8px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: #007bff;
            color: white;
            box-shadow: 0 4px 10px rgba(0, 123, 255, 0.3);
        }

        .sidebar a i {
            margin-right: 15px;
            font-size: 1.3rem;
        }

        .content {
            margin-left: 270px;
            padding: 80px 30px 30px;
        }

        .form-container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            color: #0044cc;
            font-size: 2rem;
            margin-bottom: 25px;
        }

        .input-group-text {
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-right: none;
        }

        .search-input {
            border-left: none;
            box-shadow: none;
        }

        .table thead th {
            white-space: nowrap;
        }

        .table tbody td {
            vertical-align: middle;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        footer {
            margin-top: 30px;
            background-color: #f4f7fa;
            color: #333;
            text-align: center;
            padding: 15px 0;
            border-top: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <h1>LTALVA Company</h1>
        </div>
    </header>

    <div class="sidebar">
        <a href="aloginwel.php" class="<?php echo ($current_page == 'aloginwel.php') ? 'active' : ''; ?>"><i class="fas fa-home"></i> Trang chủ</a>
        <a href="addemp.php" class="<?php echo ($current_page == 'addemp.php') ? 'active' : ''; ?>"><i class="fas fa-user-plus"></i> Thêm nhân viên</a>
        <a href="viewemp.php" class="<?php echo ($current_page == 'viewemp.php') ? 'active' : ''; ?>"><i class="fas fa-users"></i> Danh sách nhân viên</a>
        <a href="assign.php" class="<?php echo ($current_page == 'assign.php') ? 'active' : ''; ?>"><i class="fas fa-briefcase"></i> Giao dự án</a>
        <a href="assignproject.php" class="<?php echo ($current_page == 'assignproject.php') ? 'active' : ''; ?>"><i class="fas fa-chart-bar"></i> Trạng thái dự án</a>
        <a href="salaryemp.php" class="<?php echo ($current_page == 'salaryemp.php') ? 'active' : ''; ?>"><i class="fas fa-cash-register"></i> Bảng lương</a>
        <a href="empleave.php" class="<?php echo ($current_page == 'empleave.php') ? 'active' : ''; ?>"><i class="fas fa-history"></i> Đơn xin nghỉ</a>
        <a href="logout.php" class="<?php echo ($current_page == 'logout.php') ? 'active' : ''; ?>"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
    </div>

    <div class="content">
        <div class="form-container">
            <h2 class="text-center">Danh sách nhân viên</h2>
            <div class="input-group mb-3">
                <span class="input-group-text" id="search-icon">
                    <i class="fas fa-search"></i>
                </span>
                <input type="text" id="searchInput" class="form-control search-input" placeholder="Tìm kiếm nhân viên..." aria-label="Tìm kiếm" aria-describedby="search-icon">
            </div>
            <table class="table table-striped" id="employeeTable">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Ảnh đại diện</th>
                        <th scope="col">Tên</th>
                        <th scope="col">Email</th>
                        <th scope="col">Ngày sinh</th>
                        <th scope="col">Giới tính</th>
                        <th scope="col">Số điện thoại</th>
                        <th scope="col">Địa chỉ</th>
                        <th scope="col">Phòng ban</th>
                        <th scope="col">Bằng cấp</th>
                        <th scope="col">Điểm</th>
                        <th scope="col">Tùy chọn</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($employee = mysqli_fetch_assoc($result)) {
                        $gender = $employee['gender'] == 'Male' ? 'Nam' : 'Nữ';
                        $birthday = date("d/m/Y", strtotime($employee['birthday']));
                        echo "<tr>";
                        echo "<td>".$employee['id']."</td>";
                        echo "<td><img src='process/".$employee['pic']."' height='60px' width='60px'></td>";
                        echo "<td>".$employee['lastName']." ".$employee['firstName']."</td>";
                        echo "<td>".$employee['email']."</td>";
                        echo "<td>".$birthday."</td>";
                        echo "<td>".$gender."</td>";
                        echo "<td>".$employee['contact']."</td>";
                        echo "<td>".$employee['address']."</td>";
                        echo "<td>".$employee['dept']."</td>";
                        echo "<td>".$employee['degree']."</td>";
                        echo "<td>".$employee['points']."</td>";
                        echo "<td>
                            <a href='edit.php?id=".$employee['id']."' class='btn btn-primary btn-sm'><i class='fas fa-edit'></i></a>
                            <a href='delete.php?id=".$employee['id']."' class='btn btn-danger btn-sm' onClick=\"return confirm('Bạn có chắc chắn muốn xóa?')\"><i class='fas fa-trash-alt'></i></a>
                        </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 LTALVA Company. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#searchInput").on("keyup", function() {
                var query = $(this).val();
                $.ajax({
                    url: "search.php",
                    method: "GET",
                    data: { query: query },
                    success: function(data) {
                        $("#employeeTable tbody").html(data);
                    }
                });
            });
        });
    </script>
</body>
</html>
