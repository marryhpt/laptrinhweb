<?php
session_start();
require_once ('process/dbh.php');
if (!isset($_SESSION['id'])){
	header('location:logout.php');
}else{
    //check quyen
    $id=$_SESSION['id'];
    $sql = "SELECT * from `alogin` WHERE id=$id";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) == 0){
        header("Location: logout.php");
    }
}
$sql = "SELECT * from `employee`, `rank` WHERE employee.id = rank.eid";
$result = mysqli_query($conn, $sql);

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
	<title>Quản lý | Hệ thống quản lý nhân viên</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

	<style>
        .active-nav {
            background-color: #ffc107 !important;
            color: white !important;
            border-radius: 5px;
        }
		.table thead th {
            white-space: nowrap;
        }
        .table tbody td {
            vertical-align: middle;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .col-id {
            width: 50px;
        }
        .col-avatar {
            width: 100px;
        }
        .col-name {
            width: 200px;
        }
        .col-email {
            width: 200px;
        }
        .col-birthday,
        .col-gender,
        .col-contact,
        .col-dept,
        .col-degree,
        .col-points {
            width: 120px;
        }
        .col-address {
            width: 250px;
        }
        .col-options {
            width: 100px;
            text-align: center;
        }
    </style>
</head>
<body>
	<header>
		<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #28a745;">
            <a class="navbar-brand text-white" href="#">HVT Company</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'aloginwel.php') ? 'active-nav' : ''; ?>" href="aloginwel.php">Trang chủ</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'addemp.php') ? 'active-nav' : ''; ?>" href="addemp.php">Thêm nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'viewemp.php') ? 'active-nav' : ''; ?>" href="viewemp.php">Danh sách nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'assign.php') ? 'active-nav' : ''; ?>" href="assign.php">Giao dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'assignproject.php') ? 'active-nav' : ''; ?>" href="assignproject.php">Trạng thái dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'salaryemp.php') ? 'active-nav' : ''; ?>" href="salaryemp.php">Bảng lương</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'empleave.php') ? 'active-nav' : ''; ?>" href="empleave.php">Đơn xin nghỉ</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="logout.php">ĐĂNG XUẤT</a></li>
                </ul>
            </div>
        </nav>
	</header>
	<div class="container mt-5">
    <h2 class="text-center mb-4">Danh sách nhân viên</h2>
    <input type="text" id="searchInput" class="form-control mb-3" placeholder="Tìm kiếm nhân viên...">
    <table class="table table-striped" id="employeeTable">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Ảnh đại diện</th>
                <th scope="col">Tên</th>
                <th scope="col">Email</th>
                <th scope="col">Ngày sinh</th>
                <th scope="col">Giới tính</th>
                <th scope="col">Số điện thoại</th>
                <th scope="col">Địa chỉ</th>
                <th scope="col">Phòng ban</th>
                <th scope="col">Bằng cấp</th>
                <th scope="col">Điểm</th>
                <th scope="col">Tùy chọn</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while ($employee = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>".$employee['id']."</td>";
                    echo "<td><img src='process/".$employee['pic']."' height='60px' width='60px'></td>";
                    echo "<td>".$employee['lastName']." ".$employee['firstName']."</td>";
                    echo "<td>".$employee['email']."</td>";
                    echo "<td>".$employee['birthday']."</td>";
                    echo "<td>".$employee['gender']."</td>";
                    echo "<td>".$employee['contact']."</td>";
                    echo "<td>".$employee['address']."</td>";
                    echo "<td>".$employee['dept']."</td>";
                    echo "<td>".$employee['degree']."</td>";
                    echo "<td>".$employee['points']."</td>";
                    echo "<td>
                        <a href='edit.php?id=".$employee['id']."' class='btn btn-primary btn-sm'><i class='fas fa-edit'></i></a>
                        <a href='delete.php?id=".$employee['id']."' class='btn btn-danger btn-sm' onClick=\"return confirm('Bạn có chắc chắn muốn xóa?')\"><i class='fas fa-trash-alt'></i></a>
                    </td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
</div>

	<!-- Thêm Bootstrap JS và jQuery -->
	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	<script>
    $(document).ready(function() {
        $("#searchInput").on("keyup", function() {
            var query = $(this).val();
            console.log("Đang tìm: " + query);
            $.ajax({
                url: "search.php",
                method: "GET",
                data: { query: query },
                success: function(data) {
                    $("#employeeTable tbody").html(data);
                    console.log("Data received: ", data);
                },
                error: function(xhr, status, error) {
                    console.error("Ajax Error: ", status, error);
                }
            });
        });
    });
	</script>

</body>
</html>
