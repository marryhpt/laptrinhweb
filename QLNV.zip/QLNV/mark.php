<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:logout.php');
}
require_once ('process/dbh.php');
if (isset($_GET['id']) && isset($_GET['pid'])) {
    $id = $_GET['id'];
    $pid = $_GET['pid'];

    $sql1 = "SELECT pid, project.eid, project.pname, project.duedate, project.subdate, project.mark, rank.points, employee.firstName, employee.lastName, salary.base, salary.bonus, salary.total 
            FROM `project`, `rank`, `employee`, `salary` 
            WHERE project.eid = $id AND project.pid = $pid AND project.eid = rank.eid AND salary.id = project.eid AND employee.id = project.eid AND employee.id = rank.eid";

    $result1 = mysqli_query($conn, $sql1);

    if ($result1) {
        $res = mysqli_fetch_assoc($result1);
        $pname = $res['pname'];
        $duedate = $res['duedate'];
        $subdate = $res['subdate'];
        $firstName = $res['firstName'];
        $lastName = $res['lastName'];
        $mark = $res['mark'];
        $points = $res['points'];
        $base = $res['base'];
        $bonus = $res['bonus'];
        $total = $res['total'];
    }
}

if (isset($_POST['update'])) {
    $eid = mysqli_real_escape_string($conn, $_POST['eid']);
    $pid = mysqli_real_escape_string($conn, $_POST['pid']);
    $mark = mysqli_real_escape_string($conn, $_POST['mark']);
    $points = mysqli_real_escape_string($conn, $_POST['points']);
    $base = mysqli_real_escape_string($conn, $_POST['base']);
    $bonus = mysqli_real_escape_string($conn, $_POST['bonus']);

    $upPoint = $points + $mark;
    $upBonus = $bonus + $mark;
    $upSalary = $base + ($upBonus * $base) / 100;

    mysqli_query($conn, "UPDATE `project` SET `mark`='$mark' WHERE eid=$eid and pid = $pid");
    mysqli_query($conn, "UPDATE `rank` SET `points`='$upPoint' WHERE eid=$eid");
    mysqli_query($conn, "UPDATE `salary` SET `bonus`='$upBonus', `total`='$upSalary' WHERE id=$eid");

    echo "<script>
            alert('Chấm điểm thành công!');
            window.location.href='assignproject.php';
          </script>";
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Mark | Admin Panel | Hệ thống quản lý nhân viên</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .navbar {
            background-color: #003366 !important;
        }

        .navbar-brand {
            color: white !important;
            font-size: 1.5rem;
        }

        .navbar-brand:hover {
            color: #ffc107 !important;
        }

        .sidebar {
            background-color: #003366;
            color: #ffffff;
            height: 100vh;
            position: fixed;
            top: 60px;
            left: 0;
            width: 250px;
            overflow-y: auto;
            padding: 30px 0;
            border-right: 1px solid #ddd;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: #ffffff;
            text-decoration: none;
            font-size: 1rem;
            border-radius: 8px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: #007bff;
            color: white;
            box-shadow: 0 4px 10px rgba(0, 123, 255, 0.3);
        }

        .sidebar a i {
            margin-right: 15px;
            font-size: 1.3rem;
        }

        .content {
            margin-left: 270px;
            padding: 80px 30px 30px;
        }

        .form-container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            color: #0044cc;
            font-size: 2rem;
            margin-bottom: 25px;
        }

        footer {
            margin-top: 30px;
            background-color: #f4f7fa;
            color: #333;
            text-align: center;
            padding: 15px 0;
            border-top: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand" href="#">LTALVA Company</a>
        </nav>
    </header>

    <div class="sidebar">
        <a href="aloginwel.php" class="<?php echo ($current_page == 'aloginwel.php') ? 'active' : ''; ?>"><i class="fas fa-home"></i> Trang chủ</a>
        <a href="addemp.php" class="<?php echo ($current_page == 'addemp.php') ? 'active' : ''; ?>"><i class="fas fa-user-plus"></i> Thêm nhân viên</a>
        <a href="viewemp.php" class="<?php echo ($current_page == 'viewemp.php') ? 'active' : ''; ?>"><i class="fas fa-users"></i> Danh sách nhân viên</a>
        <a href="assign.php" class="<?php echo ($current_page == 'assign.php') ? 'active' : ''; ?>"><i class="fas fa-briefcase"></i> Giao dự án</a>
        <a href="assignproject.php" class="<?php echo ($current_page == 'assignproject.php') ? 'active' : ''; ?>"><i class="fas fa-chart-bar"></i> Trạng thái dự án</a>
        <a href="salaryemp.php" class="<?php echo ($current_page == 'salaryemp.php') ? 'active' : ''; ?>"><i class="fas fa-cash-register"></i> Bảng lương</a>
        <a href="empleave.php" class="<?php echo ($current_page == 'empleave.php') ? 'active' : ''; ?>"><i class="fas fa-history"></i> Đơn xin nghỉ</a>
        <a href="logout.php" class="<?php echo ($current_page == 'logout.php') ? 'active' : ''; ?>"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
    </div>

    <div class="content">
        <div class="form-container">
            <h2 class="text-center">Đánh giá</h2>
            <form action="mark.php" method="POST">
                <div class="form-group">
                    <label>Tên dự án</label>
                    <input type="text" class="form-control" name="pname" value="<?php echo $pname; ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Tên nhân viên</label>
                    <input type="text" class="form-control" name="firstName" value="<?php echo $firstName . ' ' . $lastName; ?>" readonly>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Ngày đến hạn</label>
                        <input type="text" class="form-control" name="duedate" value="<?php echo $duedate; ?>" readonly>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Ngày nộp</label>
                        <input type="text" class="form-control" name="subdate" value="<?php echo $subdate; ?>" readonly>
                    </div>
                </div>
                <div class="form-group">
                    <label>Đánh giá</label>
                    <input type="number" class="form-control" name="mark" value="<?php echo $mark; ?>" required>
                </div>
                <input type="hidden" name="eid" value="<?php echo $id; ?>">
                <input type="hidden" name="pid" value="<?php echo $pid; ?>">
                <input type="hidden" name="points" value="<?php echo $points; ?>">
                <input type="hidden" name="base" value="<?php echo $base; ?>">
                <input type="hidden" name="bonus" value="<?php echo $bonus; ?>">
                <div class="form-group text-center">
                    <button type="submit" name="update" class="btn btn-primary">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 LTALVA Company. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
