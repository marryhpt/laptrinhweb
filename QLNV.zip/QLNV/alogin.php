<?php 
session_start();
require_once ('process/dbh.php');
if (isset($_SESSION['id'])){
	$id = $_SESSION['id'];
	$sql = "SELECT * FROM `admin` WHERE id = $id"; // Sử dụng bảng 'admin' cho quản lý
	$result = mysqli_query($conn, $sql);
	if(mysqli_num_rows($result) == 1){
		header("Location: aloginwel.php"); // Chuyển hướng đến trang quản lý
	}
}
?>
<!DOCTYPE html>
<html lang="vi">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Đăng nhập | Hệ thống quản lý nhân viên</title>
	<!-- Bootstrap CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster|Montserrat" rel="stylesheet">
	<style>
		body {
			background-color: #f4f7fa;
			font-family: 'Roboto', sans-serif;
			margin: 0;
			padding: 0;
		}

		header {
			background-color: #0044cc;
			padding: 20px 0;
		}

		header h1 {
			color: white;
			text-align: center;
			font-family: 'Lobster', cursive;
			font-size: 2.5rem;
		}

		#navli {
			list-style-type: none;
			padding: 0;
		}

		#navli li {
			display: inline;
			margin: 0 15px;
		}

		#navli a {
			color: #fff;
			text-decoration: none;
		}

		#navli a:hover {
			color: #ffc107;
		}

		.loginbox {
			max-width: 400px;
			margin: 100px auto;
			padding: 30px;
			background-color: white;
			border-radius: 15px;
			box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
		}

		.loginbox h1 {
			margin-bottom: 20px;
			text-align: center;
			font-size: 1.5rem;
			color: #0044cc;
		}

		.loginbox p {
			margin-bottom: 5px;
		}

		.loginbox input[type="text"],
		.loginbox input[type="password"] {
			width: 100%;
			padding: 12px;
			margin-bottom: 15px;
			border: 1px solid #ddd;
			border-radius: 8px;
		}

		.loginbox input[type="submit"] {
			width: 100%;
			padding: 12px;
			background-color: #0044cc;
			color: white;
			border: none;
			border-radius: 8px;
			font-size: 1.2rem;
			cursor: pointer;
		}

		.loginbox input[type="submit"]:hover {
			background-color: #0056b3;
		}

		footer {
			margin-top: 30px;
			background-color: #f4f7fa;
			color: #333;
			text-align: center;
			padding: 15px 0;
		}
	</style>
</head>

<body>

	<header>
		<nav class="navbar navbar-expand-lg navbar-dark">
			<div class="container">
				<h1>HỆ THỐNG QUẢN LÝ NHÂN VIÊN</h1>
				<ul id="navli" class="navbar-nav">
					<li class="nav-item"><a class="nav-link" href="index.html">TRANG CHỦ</a></li>
					<li class="nav-item"><a class="nav-link" href="elogin.php">NHÂN VIÊN</a></li>
					<li class="nav-item"><a class="nav-link homered" href="alogin.php">QUẢN LÝ</a></li>
				</ul>
			</div>
		</nav>
	</header>

	<div class="loginbox">
		<img src="assets/admin.png" class="avatar img-fluid mx-auto d-block" alt="Admin Avatar">
		<h1>Quản lý đăng nhập</h1>
		<form action="process/aprocess.php" method="POST">
			<p>Email</p>
			<input type="text" name="mailuid" placeholder="Nhập Email" required="required">
			<p>Mật khẩu</p>
			<input type="password" name="pwd" placeholder="Nhập mật khẩu" required="required">
			<input type="submit" name="login-submit" value="Đăng nhập">
		</form>
	</div>

	<footer>
		<p>&copy; 2024 LTALVA Company. All rights reserved.</p>
	</footer>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
