<?php
session_start();
require_once('process/dbh.php');
if (!isset($_SESSION['id'])) {
    header('location:logout.php');
}else{
    //check quyen
    $id=$_SESSION['id'];
    $sql = "SELECT * from `alogin` WHERE id=$id";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) == 0){
        header("Location: logout.php");
    }
}

$sql = "SELECT employee.id, employee.firstName, employee.lastName, employee_leave.start, employee_leave.end, employee_leave.reason, employee_leave.status, employee_leave.token 
        FROM employee 
        JOIN employee_leave ON employee.id = employee_leave.id 
        ORDER BY employee_leave.token";
$result = mysqli_query($conn, $sql);

$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <title>Yêu cầu nghỉ | Hệ thống quản lý nhân viên</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .active-nav {
            background-color: #ffc107 !important;
            color: white !important;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #28a745;">
            <a class="navbar-brand text-white" href="#">HVT Company</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'aloginwel.php') ? 'active-nav' : ''; ?>" href="aloginwel.php">Trang chủ</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'addemp.php') ? 'active-nav' : ''; ?>" href="addemp.php">Thêm nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'viewemp.php') ? 'active-nav' : ''; ?>" href="viewemp.php">Danh sách nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'assign.php') ? 'active-nav' : ''; ?>" href="assign.php">Giao dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'assignproject.php') ? 'active-nav' : ''; ?>" href="assignproject.php">Trạng thái dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'salaryemp.php') ? 'active-nav' : ''; ?>" href="salaryemp.php">Bảng lương</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'empleave.php') ? 'active-nav' : ''; ?>" href="empleave.php">Đơn xin nghỉ</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="logout.php">ĐĂNG XUẤT</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Danh sách đơn xin nghỉ</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Token</th>
                    <th>Tên</th>
                    <th>Ngày bắt đầu</th>
                    <th>Ngày kết thúc</th>
                    <th>Tổng số ngày</th>
                    <th>Lý do</th>
                    <th>Trạng thái</th>
                    <th>Tùy chọn</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($employee = mysqli_fetch_assoc($result)) {
                    $date1 = new DateTime($employee['start']);
                    $date2 = new DateTime($employee['end']);
                    $interval = $date1->diff($date2);
                    echo "<tr>";
                    echo "<td>" . $employee['id'] . "</td>";
                    echo "<td>" . $employee['token'] . "</td>";
                    echo "<td>" . $employee['lastName'] . " " . $employee['firstName'] . "</td>";
                    echo "<td>" . $employee['start'] . "</td>";
                    echo "<td>" . $employee['end'] . "</td>";
                    echo "<td>" . $interval->days . "</td>";
                    echo "<td>" . $employee['reason'] . "</td>";
                    echo "<td>" . $employee['status'] . "</td>";
                    echo "<td>
                            <a href=\"approve.php?id={$employee['id']}&token={$employee['token']}\" class='btn btn-success btn-sm' onClick=\"return confirm('Bạn có chắc chắn muốn phê duyệt yêu cầu?')\">Phê duyệt</a>
                            <a href=\"cancel.php?id={$employee['id']}&token={$employee['token']}\" class='btn btn-danger btn-sm' onClick=\"return confirm('Bạn có chắc chắn muốn hủy yêu cầu?')\">Hủy</a>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Thêm Bootstrap JS và jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
