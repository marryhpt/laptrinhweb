<?php
session_start();
require_once ('process/dbh.php');
if (!isset($_SESSION['id'])){
    header('location:logout.php');
}else{
    //check quyen
    $id=$_SESSION['id'];
    $sql = "SELECT * from `alogin` WHERE id=$id";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) == 0){
        header("Location: logout.php");
    }
}

$sql = "SELECT * from `project` order by subdate desc";
$result = mysqli_query($conn, $sql);
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trạng thái dự án | Hệ thống quản lý nhân viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        .active-nav {
            background-color: #ffc107 !important;
            color: white !important;
            border-radius: 5px;
        }

        .navbar {
            background-color: #0044cc;
            color: white;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .navbar h1 {
            font-size: 2rem;
            margin: 0;
            color: white;
            font-weight: bold;
        }

        .sidebar {
            background-color: #003366;
            color: #ffffff;
            height: 100vh;
            position: fixed;
            top: 60px;
            left: 0;
            width: 250px;
            overflow-y: auto;
            padding: 30px 0;
            border-right: 1px solid #ddd;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: #ffffff;
            text-decoration: none;
            font-size: 1rem;
            border-radius: 8px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: #007bff;
            color: white;
            box-shadow: 0 4px 10px rgba(0, 123, 255, 0.3);
        }

        .sidebar a i {
            margin-right: 15px;
            font-size: 1.3rem;
        }

        .content {
            margin-left: 270px;
            padding: 80px 30px 30px;
        }

        .form-container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            color: #0044cc;
            font-size: 2rem;
            margin-bottom: 25px;
        }

        footer {
            margin-top: 30px;
            background-color: #f4f7fa;
            color: #333;
            text-align: center;
            padding: 15px 0;
            border-top: 1px solid #ddd;
        }
    </style>
</head>

<body>
    <header>
        <div class="navbar">
            <h1>LTALVA Company</h1>
        </div>
    </header>

    <div class="sidebar">
        <a href="aloginwel.php" class="<?php echo ($current_page == 'aloginwel.php') ? 'active' : ''; ?>"><i class="fas fa-home"></i> Trang chủ</a>
        <a href="addemp.php" class="<?php echo ($current_page == 'addemp.php') ? 'active' : ''; ?>"><i class="fas fa-user-plus"></i> Thêm nhân viên</a>
        <a href="viewemp.php" class="<?php echo ($current_page == 'viewemp.php') ? 'active' : ''; ?>"><i class="fas fa-users"></i> Danh sách nhân viên</a>
        <a href="assign.php" class="<?php echo ($current_page == 'assign.php') ? 'active' : ''; ?>"><i class="fas fa-briefcase"></i> Giao dự án</a>
        <a href="assignproject.php" class="<?php echo ($current_page == 'assignproject.php') ? 'active' : ''; ?>"><i class="fas fa-chart-bar"></i> Trạng thái dự án</a>
        <a href="salaryemp.php" class="<?php echo ($current_page == 'salaryemp.php') ? 'active' : ''; ?>"><i class="fas fa-cash-register"></i> Bảng lương</a>
        <a href="empleave.php" class="<?php echo ($current_page == 'empleave.php') ? 'active' : ''; ?>"><i class="fas fa-history"></i> Đơn xin nghỉ</a>
        <a href="logout.php" class="<?php echo ($current_page == 'logout.php') ? 'active' : ''; ?>"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
    </div>

    <div class="content">
        <div class="form-container">
            <h2 class="text-center mb-4">Trạng thái dự án</h2>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Task ID</th>
                        <th scope="col">Mã nhân viên</th>
                        <th scope="col">Tên dự án</th>
                        <th scope="col">Ngày đến hạn</th>
                        <th scope="col">Ngày nộp</th>
                        <th scope="col">Điểm</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Tùy chọn</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($employee = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>".$employee['pid']."</td>";
                        echo "<td>".$employee['eid']."</td>";
                        echo "<td>".$employee['pname']."</td>";
                        echo "<td>".$employee['duedate']."</td>";
                        echo "<td>".$employee['subdate']."</td>";
                        echo "<td>".$employee['mark']."</td>";
                        echo "<td>".$employee['status']."</td>";
                        echo "<td><a href='mark.php?id=".$employee['eid']."&pid=".$employee['pid']."' class='btn btn-primary btn-sm'>Đánh giá</a></td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 LTALVA Company. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
