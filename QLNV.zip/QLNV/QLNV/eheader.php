<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<header>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #28a745;">
        <a class="navbar-brand text-white" href="#">HVT Company</a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'eloginwel.php') ? 'active-nav' : ''; ?>" href="eloginwel.php">Trang chủ</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'myprofile.php') ? 'active-nav' : ''; ?>" href="myprofile.php">Hồ sơ</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'empproject.php') ? 'active-nav' : ''; ?>" href="empproject.php">Dự án</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'applyleave.php') ? 'applyleave.php' : ''; ?>" href="applyleave.php">Xin nghỉ</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="logout.php">ĐĂNG XUẤT</a></li>
            </ul>
        </div>
    </nav>
</header>
