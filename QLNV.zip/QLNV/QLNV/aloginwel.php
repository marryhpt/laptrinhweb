<?php 
session_start();
require_once ('process/dbh.php');
if (!isset($_SESSION['id'])){
	header('location:logout.php');
}else{
	//check quyen
	$id=$_SESSION['id'];
	$sql = "SELECT * from `alogin` WHERE id=$id";
	$result = mysqli_query($conn, $sql);
	if(mysqli_num_rows($result) == 0){
		header("Location: logout.php");
	}
}


$sql = "SELECT id, firstName, lastName, points FROM employee, rank WHERE rank.eid = employee.id order by rank.points desc";
$result = mysqli_query($conn, $sql);

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="utf-8">
	<title>Quản lý | Hệ thống quản lý nhân viên</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<style>
		.bg-green {
			background-color: #28a745 !important;
		}

		.navbar-nav {
			margin-left: auto;
		}
		.active-nav {
            background-color: #ffc107 !important;
            color: white !important;
            border-radius: 5px;
        }
	</style>
</head>
<body>
	<header>
		<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #28a745;">
            <a class="navbar-brand text-white" href="index.html">HVT Company</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'aloginwel.php') ? 'active-nav' : ''; ?>" href="aloginwel.php">Trang chủ</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'addemp.php') ? 'active-nav' : ''; ?>" href="addemp.php">Thêm nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'viewemp.php') ? 'active-nav' : ''; ?>" href="viewemp.php">Danh sách nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'assign.php') ? 'active-nav' : ''; ?>" href="assign.php">Giao dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'assignproject.php') ? 'active-nav' : ''; ?>" href="assignproject.php">Trạng thái dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'salaryemp.php') ? 'active-nav' : ''; ?>" href="salaryemp.php">Bảng lương</a></li>
                    <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'empleave.php') ? 'active-nav' : ''; ?>" href="empleave.php">Đơn xin nghỉ</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="logout.php">ĐĂNG XUẤT</a></li>
                </ul>
            </div>
        </nav>
	</header>
	 
	<div class="container mt-5">
		<h2 class="text-center">Leaderboard</h2>
		<table class="table table-striped">
			<thead>
				<tr>
					<th scope="col">STT</th>
					<th scope="col">ID</th>
					<th scope="col">Tên</th>
					<th scope="col">Điểm</th>
				</tr>
			</thead>
			<tbody>
			<?php
				$seq = 1;
				while ($employee = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$seq."</td>";
					echo "<td>".$employee['id']."</td>";
					echo "<td>".$employee['lastName']." ".$employee['firstName']."</td>";
					echo "<td>".$employee['points']."</td>";
					echo "</tr>";
					$seq+=1;
				}
			?>
			</tbody>
		</table>
		<div class="text-right mt-3">
			<a href="reset.php" class="btn btn-danger">Reset</a>
		</div>
	</div>

	
</body>
</html>
