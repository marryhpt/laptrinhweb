<?php
session_start();
if (!isset($_SESSION['id'])){
    header('location:logout.php');
}
require_once ('process/dbh.php');

if(isset($_POST['update'])) {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $firstname = mysqli_real_escape_string($conn, $_POST['firstName']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastName']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $birthday = mysqli_real_escape_string($conn, $_POST['birthday']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $dept = mysqli_real_escape_string($conn, $_POST['dept']);
    $degree = mysqli_real_escape_string($conn, $_POST['degree']);

    // Xử lý upload ảnh
    $imagePath = "";
    if(isset($_FILES['profilePicture']) && $_FILES['profilePicture']['error'] == 0) {
        $targetDir = "images/";
        $imagePath = $targetDir . basename($_FILES["profilePicture"]["name"]);
        move_uploaded_file($_FILES["profilePicture"]["tmp_name"], $imagePath);
        // Cập nhật thông tin khác bao gồm cả ảnh
        $sql = "UPDATE `employee` SET `firstName`='$firstname', `lastName`='$lastname', `email`='$email', `birthday`='$birthday', `gender`='$gender', `contact`='$contact', `address`='$address', `dept`='$dept', `degree`='$degree', `pic`='$imagePath' WHERE id=$id";
    } else {
        // Cập nhật ảnh
        $sql = "UPDATE `employee` SET `firstName`='$firstname', `lastName`='$lastname', `email`='$email', `birthday`='$birthday', `gender`='$gender', `contact`='$contact', `address`='$address', `dept`='$dept', `degree`='$degree' WHERE id=$id";
    }
    if (mysqli_query($conn, $sql)) {
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Cập nhật thành công')
        window.location.href='viewemp.php';
        </SCRIPT>");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<?php
$id = (isset($_GET['id']) ? $_GET['id'] : '');
$sql = "SELECT * from `employee` WHERE id=$id";
$result = mysqli_query($conn, $sql);
if ($result) {
    while ($res = mysqli_fetch_assoc($result)) {
        $firstname = $res['firstName'];
        $lastname = $res['lastName'];
        $email = $res['email'];
        $contact = $res['contact'];
        $address = $res['address'];
        $gender = $res['gender'];
        $birthday = $res['birthday'];
        $dept = $res['dept'];
        $degree = $res['degree'];
    }
}
?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="utf-8">
    <title>Quản lý | Hệ thống quản lý nhân viên</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #28a745;">
            <a class="navbar-brand text-white" href="#">HVT Company</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link text-white" href="aloginwel.php">Trang chủ</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="addemp.php">Thêm nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="viewemp.php">Danh sách nhân viên</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="assign.php">Giao dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="assignproject.php">Trạng thái dự án</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="salaryemp.php">Bảng lương</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="empleave.php">Đơn xin nghỉ</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="logout.php">ĐĂNG XUẤT</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <div class="container mt-5">
        <h2 class="text-center">Thông tin</h2>
        <div class="card mt-3">
            <div class="card-body">
                <form action="edit.php" method="POST" enctype="multipart/form-data">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <input class="form-control" type="text" value="<?php echo $lastname;?>" name="lastName" required>
                        </div>
                        <div class="form-group col-md-6">
                            <input class="form-control" type="text" value="<?php echo $firstname;?>" name="firstName" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="email" value="<?php echo $email;?>" name="email" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Ngày sinh</label>
                            <input class="form-control" type="date" value="<?php echo $birthday;?>" name="birthday" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Giới tính</label>
                            <select name="gender" class="form-control" required>
                                <option value="<?php echo $gender ?>"><?php echo $gender ?></option>
                                <option value="Male">Nam</option>
                                <option value="Female">Nữ</option>
                                <option value="Other">Khác</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" value="<?php echo $contact;?>" name="contact" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" value="<?php echo $address;?>" name="address" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" value="<?php echo $dept;?>" name="dept" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" value="<?php echo $degree;?>" name="degree" required>
                    </div>
                    <div class="form-group">
                        <label for="profilePicture">Ảnh đại diện</label>
                        <input type="file" class="form-control-file" id="profilePicture" name="profilePicture">
                    </div>
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <button type="submit" name="update" class="btn btn-success">Gửi</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
